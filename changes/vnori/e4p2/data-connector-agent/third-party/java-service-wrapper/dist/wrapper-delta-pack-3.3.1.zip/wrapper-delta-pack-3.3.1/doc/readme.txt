Java Service Wrapper

Complete documentation can be found online:
http://wrapper.tanukisoftware.org

Java docs are available online as well:
http://wrapper.tanukisoftware.org/jdoc/index.html

/* $OpenBSD: version.h,v 1.52 2008/03/27 00:16:49 djm Exp $ */

#define SSH_VERSION	"OpenSSH_4.9"

#define SSH_PORTABLE	"p1"
#define SSH_RELEASE	SSH_VERSION SSH_PORTABLE

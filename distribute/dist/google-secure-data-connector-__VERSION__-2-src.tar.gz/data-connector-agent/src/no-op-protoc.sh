#!/bin/bash
#
# $Id$
# Copyright 2009 Google Inc. All Rights Reserved.
# Author: rayc@google.com (Ray Colline)

echo Protoc not detected on your system.  Using pre-generated classes.  
echo If you wish to edit $2, you must install protoc.  
echo Available at: http://code.google.com/p/protobuf/
